package com.company;

import org.junit.Assert;
import org.junit.Test;

public class CalculatorTest {

    @Test
    public void toTestSum(){
        int a1=-6;
        int b1=6;
        Calculator numbers1= new Calculator(a1,b1);
        int a2=100;
        int b2=5;
        Calculator numbers2= new Calculator(a2,b2);
        Assert.assertEquals(Calculator.getSum(a1,b1),(a1+b1));
        Assert.assertEquals(Calculator.getSum(a2,b2),(a2+b2));
    }

    @Test
    public void toTestMinus(){
        int a1=-6;
        int b1=6;
        Calculator numbers1= new Calculator(a1,b1);
        int a2=100;
        int b2=5;
        Calculator numbers2= new Calculator(a2,b2);
        Assert.assertEquals(Calculator.getMinus(a1,b1),(a1-b1));
        Assert.assertEquals(Calculator.getMinus(a2,b2),(a2-b2));
    }

    @Test
    public void toTestMultiply(){
        int a1=-6;
        int b1=6;
        Calculator numbers1= new Calculator(a1,b1);
        int a2=100;
        int b2=5;
        Calculator numbers2= new Calculator(a2,b2);
        Assert.assertEquals(Calculator.getMultiply(a1,b1),(a1*b1));
        Assert.assertEquals(Calculator.getMultiply(a2,b2),(a2*b2));
    }

    @Test
    public void toTestDivision(){
        int a1=-6;
        int b1=6;
        Calculator numbers1= new Calculator(a1,b1);
        int a2=100;
        int b2=5;
        Calculator numbers2= new Calculator(a2,b2);
        Assert.assertEquals(Calculator.getDivision(a1,b1),(a1/b1));
        Assert.assertEquals(Calculator.getDivision(a2,b2),(a2/b2));
    }
}
